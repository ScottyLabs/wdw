WDW Flask Blog, heavily based off Miguel Grinberg microblog
=========

Installation
------------

Make sure to install pip and virtualenv.

Install pip using the instructions here: 
https://pip.pypa.io/en/latest/installing/#using-the-installer

Go into the wdwdemo directory if you are not already there.

$ cd wdwdemo
$ virtualenv flask

A Virtual Environment is a tool to keep the dependencies required by different projects in separate places, by creating virtual Python environments for them. It solves the “Project X depends on version 1.x but, Project Y needs 4.x” dilemma, and keeps your global site-packages directory clean and manageable.

To activate your virtual environment: 
$ source flask/bin/activate

To deactivate your vritaul environment:
$ deactivate

Let’s install some extensions for this application.

$ source flask/bin/activate
$ flask/bin/pip install flask
$ flask/bin/pip install flask-login
$ flask/bin/pip install flask-sqlalchemy
$ flask/bin/pip install sqlalchemy-migrate
$ flask/bin/pip install flask-wtf
$ deactivate

Windows Users:

$ flask\Scripts\pip install flask


Running
-------

To run the application in the development web server execute “python run.py” or 
$ chmod a+x 
$ ./run.py
